'use strict';
/**
 * 数据库层：使用 Node 24 内置的 node:sqlite，零外部依赖。
 * 金额统一用「整数分」存储，避免浮点误差。
 *
 * 换成华为云 RDS(MySQL) 时，只需替换本文件里的 SQL 方言和驱动，
 * 上层 routes / lib 都不用改（这就是分层的好处）。
 */
const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'sme.db');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  phone         TEXT,
  industry      TEXT,
  role          TEXT    NOT NULL DEFAULT 'staff',   -- owner(老板) | staff(店员)
  password_hash TEXT    NOT NULL,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS categories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  name       TEXT    NOT NULL,
  kind       TEXT    NOT NULL,                       -- income | expense
  color      TEXT,
  created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS transactions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id),
  date         TEXT    NOT NULL,                     -- YYYY-MM-DD
  type         TEXT    NOT NULL,                     -- income | expense
  amount_cents INTEGER NOT NULL,                     -- 金额（分），永远为正
  category_id  INTEGER REFERENCES categories(id),
  summary      TEXT,
  note         TEXT,
  source       TEXT    NOT NULL DEFAULT 'manual',    -- manual | wechat | alipay | ocr
  status       TEXT    NOT NULL DEFAULT 'confirmed', -- confirmed | pending
  created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
CREATE INDEX IF NOT EXISTS idx_tx_user_status ON transactions(user_id, status);

CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  name        TEXT    NOT NULL,
  price_cents INTEGER NOT NULL,                      -- 售价
  cost_cents  INTEGER NOT NULL,                      -- 成本价
  created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS import_jobs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  platform   TEXT    NOT NULL,                       -- wechat | alipay
  filename   TEXT,
  total      INTEGER NOT NULL DEFAULT 0,
  categorized INTEGER NOT NULL DEFAULT 0,
  pending    INTEGER NOT NULL DEFAULT 0,
  status     TEXT    NOT NULL DEFAULT 'done',        -- running | done | failed
  message    TEXT,
  created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS alerts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  type       TEXT    NOT NULL,                       -- cost_ratio | revenue_mom | no_flow
  level      TEXT    NOT NULL DEFAULT 'info',        -- high | medium | info
  title      TEXT    NOT NULL,
  detail     TEXT,
  threshold  TEXT,
  status     TEXT    NOT NULL DEFAULT 'open',        -- open | ignored
  pushed_at  TEXT,
  created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS alert_settings (
  user_id            INTEGER PRIMARY KEY REFERENCES users(id),
  cost_ratio         REAL NOT NULL DEFAULT 40,
  revenue_volatility REAL NOT NULL DEFAULT 5,
  margin_floor       REAL NOT NULL DEFAULT 30
);

CREATE TABLE IF NOT EXISTS receipts (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL REFERENCES users(id),
  image_path      TEXT,
  merchant        TEXT,
  date            TEXT,
  amount_cents    INTEGER,
  category        TEXT,
  note            TEXT,
  confidence_json TEXT,
  status          TEXT NOT NULL DEFAULT 'pending',   -- pending | confirmed
  created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
`;

function initSchema() {
  db.exec(SCHEMA);
  return db;
}

module.exports = { db, initSchema, DB_PATH };
